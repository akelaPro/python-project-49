### Hexlet tests and linter status:
[![Actions Status](https://github.com/akelaPro/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/akelaPro/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/4966aafa308e3d45a007/maintainability)](https://codeclimate.com/github/akelaPro/python-project-49/maintainability)
https://asciinema.org/a/ltcrgtHoPVTCpNvCKN8ZJkDIm
