#!/usr/bin/env python3
from brain_games.game.progression_code import progress_game



def main():
    progress_game()


if __name__ == '__main__':
    main()

