#!/usr/bin/env python3
from brain_games.game.calc_code import calc


def main():
    calc()


if __name__ == '__main__':
    main()
